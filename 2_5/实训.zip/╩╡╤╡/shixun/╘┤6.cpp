#include<stdio.h>
#include<string.h>
#include<malloc.h>

#define maxsize 1300
typedef struct node {
	char name[30];
	struct node* next;
}nodetype;

typedef struct node {
	nodetype* first;
}hash_type;

int main() {
	int n, mon, day, hash_num = 0, i, flag = 0;
	char temp[30];
	hash_type hash[maxsize];
	int many[maxsize] = {};
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		getchar();
		gets_s(temp);
		scanf("%d %d", &mon, &day);
		hash_num = 100 * mon + day;
		nodetype* p;
		p = (nodetype*)malloc(sizeof(nodetype));
		strcpy(p->name, temp);
		if (hash[hash_num].first == NULL)
			hash[hash_num].first = p;
		else {
			nodetype* r = hash[hash_num].first;
			while (r -> next != NULL) {
				if (strcmp(r->name, temp) < 0
					&& strcmp(r->next->name, temp) > 0) {
					p->next = r->next;
					r->next = p;
					flag = 1;
				}
				else
					r = r->next;
			}
			if (flag == 0) { //do not find ,insert tail
				r->next = p;
				p->next = NULL;
			}
			many[hash_num] = 1;
		}
	}
	for (i = 0; i < maxsize; i++) {
		if (many[i] == 1) {
			printf("%d %d ", i / 100, i % 100);
			nodetype *r = hash[i].first;
			while (r->next != NULL) {
				printf("%s ", r->name);
				r = r->next;
			}
		}
	}
	return 0;
}