#include<stdio.h>
#define maxsize 11000

int main() {
    int id[maxsize];
    int n, m, i = 0, j = 0, time = 1;
    scanf("%d %d", &n, &m);
    int num[m];
    int st[maxsize];
    int top = -1;
    while (i < n) {  //���
        id[i] = i + 1;
        i++;
    }
    i = 0;
    while (i < m) {     //Ҫ����ķ���
        scanf("%d", &num[i]);
        i++;
    }
    while (j < m) {
        for (i = num[j] - 1; i < n - j; i++) {
            num[i] = num[i + 1];
        }
        j++;
    }
    printf("%d", num[(n - m - 1) / 2]);
    return 0;
}