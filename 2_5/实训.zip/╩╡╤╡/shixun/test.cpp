#include<stdio.h>

#define maxsize 1000100

int main() {
    /*freopen("max.in", "r", stdin);
    freopen("max.out", "w", stdout);*/
    int n, i;
    int a[maxsize] = {};
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    long long int sum = a[0];
    long long int max = a[0];
    for (i = 1; i < n; i++) {
        if (sum <= 0)
            sum = 0;
        sum += a[i];
        max = (sum > max) ? sum : max;
    }
    printf("%d", max);
    return 0;
}