#include<stdio.h>
#include<stdlib.h>
#define get_small(a, b) ((a - 1) / 3) * 3 + (b - 1) / 3
#define isNum(c) (c <= '9' && c >= '1')
#define max(a, b) (a > b ? (a) : (b))
int map[10][10];
int col[10][10], row[10][10], small[10][10];
int s, max_score;

int judge(int x, int y, int num) {
    int no = get_small(x, y);
    if (!col[x][num] && !row[y][num] && !small[no][num])
        return 1;
    else
        return 0;
}
int score(int x, int y) {
    if (x == 1 || y == 1 || x == 9 || y == 9) return 6;
    if (x == 2 || y == 2 || x == 8 || y == 8) return 7;
    if (x == 2 || y == 2 || x == 8 || y == 8) return 8;
    if (x == 2 || y == 2 || x == 8 || y == 8) return 9;
    return 10;
}
void debug() {
    for (int i = 1; i <= 9; i++) {
        for (int j = 1; j <= 9; j++) {
            printf("%d ", map[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
void dfs(int step, int sum) {
    if (step == 81) {
        max_score = max(max_score, sum);
        return;
    }
    for (int i = 9; i >= 1; i--) {
        for (int j = 9; j >= 1; j--) {
            if (map[i][j] != 0) {
                step++;
                continue;
            }
            for (int k = 1; k <= 9; k++) {
                int no = get_small(i, j);
                if (!col[i][k] && !row[j][k] && !small[no][k]) {
                    col[i][k] = 1;
                    row[j][k] = 1;
                    small[no][k] = 1;
                    map[i][j] = k;
                    step++;
                    dfs(step, sum + k * score(i, j));
                    step--;
                    col[i][k] = 0;
                    row[j][k] = 0;
                    small[no][k] = 0;
                    map[i][j] = 0;
                }
            }
            return;
        }
    }
    return;
}


int main() {
    for (int i = 1; i <= 9; i++) {
        for (int j = 1; j <= 9; j++) {
            scanf("%d", &map[i][j]);
            s += map[i][j] * score(i, j);
        }
    }
    dfs(1, s);
    if (s == 0)
        s = -1;
    printf("%d", s);
    return 0;
}