#include<stdio.h>
#include<string.h>
#define maxsize 120
#define maxlen  1100
int dir[5][2] = { {1, 0}, {-1, 0}, {0, 1}, {0, -1}, {0, 0} };
int n, m, k, d, l, r, flag, min_time;
int visit[maxsize][maxsize][maxlen];
int kill[maxsize][maxsize][maxlen];
struct point {
    int x, y;
    int time;
} q[maxlen];
struct Soldier {
    char dir;
    int T, v;
    int x, y;
} s[maxsize];

int in(int x, int y) {
    return (0 <= x && x <= n && 0 <= y && y <= m);
}
int iskill(int cur_time, int cur_i, int cur_j) {
    int kill_i = cur_i, kill_j = cur_j;
    for (int i = 0; i < k; i++) {
        switch (s[i].dir) {
        case 'W': kill_j = s[i].y - s[i].v * cur_time;
            break;
        case 'N': kill_i = s[i].x - s[i].v * cur_time;
            break;
        case 'S': kill_i = s[i].x + s[i].v * cur_time;
            break;
        case 'E': kill_j = s[i].y + s[i].v * cur_time;
            break;
        }
        if (cur_i == kill_i && cur_j == kill_j)
            return 0;   //fail
    }
    return 1;
}
void bfs() {
    l = r = 0;
    struct point start = { 0, 0, 0 };
    visit[0][0][0] = 1;
    q[r] = start;
    r = (r + 1) % maxlen;
    while (l != r) {
        struct point now = q[l];
        l = (l + 1) % maxlen;
        int nx, ny, ntime;
        for (int i = 0; i < 5; i++) {
            nx = now.x + dir[i][0];
            ny = now.y + dir[i][1];
            ntime = now.time + 1;
            if (in(nx, ny)) {
                if (!kill[nx][ny][ntime] && !visit[nx][ny][ntime]) {
                    if (ntime > d) {
                        printf("Bad Luck!");
                        return;
                    }
                    if (nx == n && ny == m) {
                        printf("%d", ntime);
                        return;
                    }
                    visit[nx][ny][ntime] = 1;
                    struct point temp = { nx, ny, ntime };
                    q[r] = temp;
                    r = (r + 1) % maxlen;
                }
            }
        }
    }
}
int main() {
    memset(kill, 0, sizeof(kill));
    memset(visit, 0, sizeof(visit));
    flag = 1;
    scanf("%d %d %d %d", &n, &m, &k, &d);
    //getchar();
    char tdir;
    int tt, tx, ty, tv;
    for (int i = 0; i < k; i++) {
        getchar();
        scanf("%c%d%d%d%d", &tdir, &tt, &tv, &tx, &ty);
        for (int i = 0; i <= d; i++)
            kill[tx][ty][i] = 1;
        if (tdir == 'W') {
            int tmp = ty;
            while ((tmp -= tv) >= 0) {
                kill[tx][tmp][(ty - tmp) / tv] = 1;
                int tmp_t = 0;
                while (tmp_t = tmp_t + tt) {
                    if (tmp_t + (ty - tmp) / tv > d) break;
                    kill[tx][tmp][(ty - tmp) / tv + tmp_t] = 1;
                }
            }
        }
        if (tdir == 'N') {
            int tmp = tx;
            while ((tmp -= tv) >= 0) {
                kill[tmp][tx][(tx - tmp) / tv] = 1;
                int tmp_t = 0;
                while (tmp_t = tmp_t + tt) {
                    if (tmp_t + (tx - tmp) / tv > d) break;
                    kill[tmp][ty][(tx - tmp) / tv + tmp_t] = 1;
                }
            }
        }
        if (tdir == 'S') {
            int tmp = tx;
            while ((tmp += tv) >= 0) {
                if (tmp > n) break;
                kill[tmp][ty][(tx + tmp) / tv] = 1;
                int tmp_t = 0;
                while (tmp_t = tmp_t + tt) {
                    if (tmp_t + (tx + tmp) / tv > d) break;
                    kill[tmp][ty][(tx + tmp) / tv + tmp_t] = 1;
                }
            }
        }
        if (tdir == 'E') {
            int tmp = ty;
            while ((tmp += tv) >= 0) {
                if (tmp > m) break;
                kill[tx][tmp][(ty + tmp) / tv] = 1;
                int tmp_t = 0;
                while (tmp_t = tmp_t + tt) {
                    if (tmp_t + (ty + tmp) / tv > d) break;
                    kill[tx][tmp][(ty + tmp) / tv + tmp_t] = 1;
                }
            }
        }
        struct Soldier tmp = { tdir, tt, tv, tx, ty };
        s[i] = tmp;
    }
    bfs();
    //bfs(0, 0, 0);
    return 0;
}