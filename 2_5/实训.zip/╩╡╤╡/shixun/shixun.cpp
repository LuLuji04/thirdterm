﻿

#include <iostream>
#include<stdio.h>
#include<string.h>
#include <cstdio>
#include<memory.h>


//#define size 20

using namespace std;


//head is .. output 'Value Error'
//1 -> error
int isError(char str[][100], int i)
{
    if (str[i][0] == '.' && str[i][1] == '.')
        //printf("Value Error");
        return 1;
    else
        return 0;
}

//judge char '\' or '/' ,return place
int ischar(char str[][100],int i,int j)
{
    int count = 0;
    while (str[i][j] == '\\'|| str[i][j] == '/' )
    {
        count++;
        j++;
    }
    return count;
}

//judge is . or not
// 0 means bot .
int isbot(char ch)
{
    if (ch == '.')
        return 0;
    else
        return 1;
}
int main()
{
    char str[10][100];
    int i = 0, j = 0;
    int head_flag;
    scanf("%s", &str[i]);
    fflush(stdin);         //clear
    i++;
    //input
    while (str[i][0] != '\0' && i < 10 && str[i][0] != ' ')
    {
        scanf("%s",&str[i]);
        fflush(stdin);
        i++;
    }
    int column = i;        //get the value of column
    int row[10];
    memset(row, 10, 0);
    for(i = 0; i < column; i++)
    {
        while (str[i][j] != '\0')
        {
            row[i]++;             //get every column the value of rows
        }
    }

    //output && judge
    for (i = 0; i < column; i++)
    {
        //deal every column
        for(j = 0;j < row[i];j++)
        {
            if (str[i][0] == '\\' || str[i][0] == '/')
                head_flag = 1;
            else
                head_flag = 0;
            char temp = str[i][j];
            char temp_b = str[i][j + 1];
            char temp_f = str[i][j - 1];
            if((isError(str,i) == 1))
            {
                printf("Value Error\n");
                break;
            }
            if (isbot(temp) == 1)
            {
                if ((temp <= 'z' && temp >= 'a') || temp <= 'Z' && temp >= 'A')
                {
                    printf("%c", temp);
                    j++;
                }
                else if ((temp == '\\' || temp == '/') && head_flag == 1)
                {
                    int back_move = ischar(str, i, j);
                    j += back_move ;
                    printf("/");
                }
            }
            else if (isbot(temp) == 0 && (isbot(temp_b) == 1))
            {
                j++;
            }
        }
        printf("\n");
    }
    return 0;
}
