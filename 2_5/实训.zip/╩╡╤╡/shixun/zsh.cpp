#include <stdio.h>

int maze[10][10], visit[10][10], n, sum, vis;
int dir[4][2] = { {1,0}, {-1,0}, {0,1}, {0,-1} };
//int is_onepoint(int x, int y) {
//    if (x == 1) {
//        if (visit[x][y - 1] && visit[x + 1][y]) {
//            return 1;
//        }
//    }
//    else {
//        for (int i = )
//    }
//}
int in(int x, int y) {
    if (x >= 1 && y >= 1 && x <= n && y <= n && !visit[x][y]) {
        return 1;
    }
    return 0;
}
int end(int x, int y) {
    if (((x == n - 1) && (y == 1)) || ((x == n) && (y == 2))) {
        return 0;
    }
    if (visit[n - 1][1] && visit[n][2]) {
        return 1;
    }
    return 0;
}
void dfs(int x, int y) {
    if (x == n && y == 1 && vis == (n * n - 1)) {
        sum++;
        return;
    }
    if (x == n && y == 1 && vis != (n * n - 1)) {
        return;
    }
    visit[x][y] = 1;
    vis++;
    if (!end(x, y)) {
        int mx, my, is_wei;
        is_wei = 0;
        for (int j = 0; j < 4; j++) {
            mx = x + dir[j][0];
            my = y + dir[j][1];
            /*if (is_onepoint(mx, my)) {
                is_wei = 1;
                break;
            }*/
            if (in(mx, my)) {
                dfs(mx, my);
            }
        }
    /*    for (int i = 0; i < 4; i++) {
            if (!is_wei) {
                mx = x + dir[j][0];
                my = y + dir[j][1];
            }*/

    }
    visit[x][y] = 0;
    vis--;
}
int main() {
    scanf("%d", &n);
    int num = 1;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            maze[i][j] = num;
            num++;
        }
    }
    dfs(1, 1);
    printf("%d", sum);
    return 0;
}
