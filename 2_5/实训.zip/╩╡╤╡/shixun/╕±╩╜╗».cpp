#include<stdio.h>
#include<string.h>

#define maxsize 120

int ischar(char ch) {
	if ((ch <= 'Z' && ch >= 'A')
		|| (ch <= 'z' && ch >= 'a')
		|| (ch <= '9' && ch >= '0')) {
		return 1;
	}
	else {
		return 0;
	}
}

int isslash(char ch) {
	if (ch == '\\' || ch == '/') {
		return 1;
	}
	else {
		return 0;
	}
}

void merge(char* str)
{
	char* st[maxsize];  //stack rem address not a char
	int top = -1;
	char* temp = str;
	//*temp means a char,temp means address
	while (*temp != '\0') {
		if (ischar(*temp)) {
			st[++top] = temp;     //address in stack
			while (ischar(*temp)) {
				temp++;            //skip
			}
		}
		else if (*temp == '.') {
			if (*(temp + 1) != '.') {
				temp++;
			}
			else if (*(temp + 1) == '.') {
				if (top == -1) {
					strcpy(str, "Value Error");
					return;
				}
				else {
					top--;
					temp += 2;
				}
			}
		}
		temp++;
	}
	//finally merge
	char merge[maxsize] = { 0 };
	char* m = merge;
	//the start is slash
	if (isslash(str[0])) {
		*m++ = '/';
	}

	//output
	int end = 0;
	while (end <= top) {
		//get one char
		char* ch = st[end++];
		//copy
		while (ischar(*ch) && *ch != '\0') {
			*m++ = *ch++;
		}
		*m++ = (end <= top ? '/' : '\0');
	}
	//copy
	strcpy(str, merge);
	return;
}

int main() {
	char str[maxsize];
	//scanf one line and deal one line
	while (gets_s(str)) {
		//str[strlen(str) - 1] = '\0';   //remove \n
		merge(str);
		puts(str);
	}
	return 0;
}