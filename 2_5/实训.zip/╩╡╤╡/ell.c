#include <unistd.h>
#include "shell.h"
/**
 * shell的入口
 */
void prefix() {
  char buffer[100];
  getcwd(&buffer, 100);
  printf("%s$ ", buffer);
}

#include"log.h"

int SkipSpaces(int start, char *str);
int RunProgram(char * prog, char * argv);

void display_history(node* p)
{
  if(p == NULL){
    return;
  }
  display_history(p->next);
  printf("%s\n", p->cmd);
}

void log_history()
{
  node* p;
  p = Log.head;
  display_history(p); // 递归
  return;
}

char * display_search(node* p, const char *prefix)
{
  if(p == NULL)
  {
    return NULL;
  }
  char * temp;
  temp = display_search(p->next, prefix);
//  printf("%p:%s %s\n", p->cmd, p->cmd, temp == NULL ? "NULL" : temp);
  if(temp == NULL && (strlen(prefix) <= strlen(p->cmd) && strncmp(prefix, p->cmd, strlen(prefix)) == 0)){
//    printf("return from 1, p->cmd(%p): %s\n",p->cmd, p->cmd);
    return p->cmd;
  }
  else{
//    printf("return from 2, temp(%p): %s\n", temp, temp);
    return temp;
  }
}

void cd(const char *path) {
  if (chdir(path)==-1)
    printf("%s:No such file or directory\n", path);
}

void ls() {
  system("ls");
}

int execute(char* buffer){
  //def args
  int buf_len = strlen(buffer);
  char *arg = malloc(sizeof(char) * buf_len);
  char *program = malloc(sizeof(char) * buf_len);
  arg[buf_len - 1] = '\0';
  program[buf_len - 1] = '\0';
  arg[0] = '\0';
  program[0] = '\0';


  //del space
  int pos_cmd_start = SkipSpaces(0,buffer);
  int pos = pos_cmd_start;

  //get program
  while(buffer[pos] != ' ' && buffer[pos] != '\0'){
    pos++;
  }
  memcpy(program, buffer + pos_cmd_start, pos - pos_cmd_start);
  program[pos - pos_cmd_start] = '\0';

  //get arg
  pos = SkipSpaces(pos, buffer);
  int space_flg = 0, pos_arg_end = pos, pos_arg_start = pos;
  while(buffer[pos] != '\0'){
    if(buffer[pos] == ' '){
      if(space_flg == 0){
        space_flg = 1;
        pos_arg_end = pos;
      }
    }
    else{
      space_flg = 0;
      pos_arg_end = -1;
    }
    pos++;
  }
  pos_arg_end = pos_arg_end > 0 ? pos_arg_end : pos;
  memcpy(arg, buffer + pos_arg_start,  pos_arg_end - pos_arg_start);
  arg[pos_arg_end - pos_arg_start] = '\0';

  //switch into functions
  if(strcmp("cd", program) == 0){
    cd(arg);
  }
  else if(strcmp("exit", program) == 0){
    return 0;
  }
  else if(strcmp("!#", program) == 0 && arg[0] == '\0'){
    log_history();
  }
  else if(program[0] == '!' && arg[0] == '\0'){
    char *command = log_search(&Log, program + 1);
//    printf("command: %p\n", command);
    if(command != NULL)
      execute(command);
    else
      printf("No Match\n");
  }
  else if(strcmp("ls", program) == 0){
    ls();
  }
  else{
    char * temp = program;
    if(RunProgram(temp, arg)){
      printf("%s: no such command\n", buffer);
    }
    program = temp;
  }

  if(program[0] != '!'){
    char * temp = (char *)calloc(strlen(buffer), sizeof(char));
    strcpy(temp, buffer);
    log_push(&Log, temp);
  }

  //free pointer
  free(arg);
  free(program);
  return 1;
}


int SkipSpaces(int start, char *str){
  int pos = start;
  while(str[pos] == ' '){
    pos++;
  }
  return pos;
}

int RunProgram(char * prog, char * argv) {
  while(*prog == '.' && *(prog + 1) == '/')
    prog += 2;
  pid_t pid = fork();
  int status;
  if(pid == 0) {  /* Child process */
    char * buffer[128];
    memset(buffer, 0, sizeof(buffer));
    buffer[0] = prog;
    char *start = argv, *end = argv;
    int cnt = 0;
    while(*start != '\0') {
      while(*end != ' ' && *end != '\0')
        end++;
      buffer[++cnt] = start;
      start = end;
      while(*start == ' ')
        start++;
      *end = '\0';
      end = start;
    }
    // puts("buffer:");
    // for(int i = 0; i <= cnt; i++){
    //   puts(buffer[i]);
    // }
    // puts("executing:");
    if(execv(prog, buffer) < 0){
      // printf("Error: %s\n", strerror(errno));
      exit(1);
    } else {
      exit(0);
    }
  }

  wait(&status);
  // printf("status:%d\n", status);
  // printf("WIFEXITED:%d\n", WIFEXITED(status));
  // printf("WEXITSTATUS:%d\n",WEXITSTATUS(status));
  if(WIFEXITED(status)){
    if(WEXITSTATUS(status) == 1){
      return -1;
    } else {
      return 0;
    }
  } else {
    puts("Child process exited abnormally");
    return -1;
  }
}