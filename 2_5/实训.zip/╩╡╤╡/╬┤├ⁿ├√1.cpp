#include<stdio.h>
#include<math.h>

typedef struct
{
    int n;
    int f;
}num;
int main()
{
    int n;
    scanf("%d",&n);
    num* x[n];
    num* temp;
    int i,j;
    for(i = 0;i < n;i++)
    {
        scanf("%d",&x[i] -> n);
        x[i] -> f = abs(x[i] -> n);
    }
    for(i = 0;i < n;i++)
    {
        for(j = 0;j < n - 1 - i;j++)
        {
            if(x[j] -> n < x[j + 1] -> n)
            {
                temp = x[j];
                x[j] = x[j + 1];
                x[j + 1] = temp;
            }
        }
    }
    for(i = 0;i < n;i++)
    {
        printf("%d ",x[i] -> n);
    }
    return 0;
}
