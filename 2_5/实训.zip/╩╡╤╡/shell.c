#include "shell.h"
#include "log.h"
#define maxsize 110
/**
 * shell的入口
 */
void prefix() {
    char cwd[maxsize];
    getcwd(&cwd, sizeof(cwd));
    printf("%s$ ", cwd);
}

void display(node* p) {
    if (p == NULL) return;
    display(p->next);
    printf("%s\n", p->cmd);
}

void history() {
    node* p;
    p = Log.head;
    display(p);
    return;
}

void cd(const char* path) {
    if (chdir(path) == 1)
        printf("%s:No such file or directory\n", path);
}

void ls() {
    system("ls");
}
int skip_space(char* str, int start) {
    int num = start;
    while (str[num] == ' ') {
        num++;
    }
    return num;
}

int Run(char* prog, char* argv) {
    while (*prog == '.' && *(prog + 1) == '/')
        prog += 2;
    pid_t pid = fork();
    int status;
    if (pid == 0) {  /* Child process */
        char* buffer[128];
        memset(buffer, 0, sizeof(buffer));
        buffer[0] = prog;
        char* start = argv, * end = argv;
        int cnt = 0;
        while (*start != '\0') {
            while (*end != ' ' && *end != '\0')
                end++;
            buffer[++cnt] = start;
            start = end;
            while (*start == ' ') {
                start++;
                *end = '\0';
                end = start;
            }
            if (execv(prog, buffer) < 0) {
                exit(1);
            }
            else {
                exit(0);
            }
        }

        wait(&status);
        if (WIFEXITED(status)) {
            if (WEXITSTATUS(status) == 1) {
                return -1;
            }
            else {
                return 0;
            }
        }
        else {
            puts("Child process exited abnormally");
            return -1;
        }
    }
}

int execute(char* buffer) {
    int len = strlen(buffer);
    char* arg = (char*)malloc(len * sizeof(char));
    char* program = (char*)malloc(len * sizeof(char));
    arg[len - 1] = program[len - 1] = '\0';
    program[0] = program[0] = '\0';

    int start = skip_space(buffer, 0);
    int pos = start;
    while (buffer[pos] != ' ' && buffer[pos] != '\0') {
        pos++;
    }
    memcpy(program, buffer + start, pos - start);
    program[pos - start] = '\0';

    pos = skip_space(buffer, pos);
    int space_flg = 0, arg_end = pos, arg_start = pos;
    while (buffer[pos] != '\0') {
        if (buffer[pos] == ' ') {
            if (space_flg == 0) {
                space_flg = 1;
                arg_end = pos;
            }
        }
        else {
            space_flg = 0;
            arg_end = -1;
        }
        pos++;
    }
    if (arg_end <= 0) arg_end = pos;
    memcpy(arg, buffer + arg_start, arg_end - arg_start);
    arg[arg_end - arg_start] = '\0';

    if (strcmp("cd", program) == 0) {
        cd(arg);
    }
    else if (strcmp("exit", program) == 0) {
        return 0;
    }
    else if (strcmp("!#", program) == 0) {
        history();
    }
    else if (program[0] == '!' && arg[0] == '\0') {
        char* command = log_search(&Log, program + 1);
        if (command != NULL) execute(command);
        else printf("No Match\n");
    }
    else if (strcmp("ls", program) == 0) {
        ls();
    }
    else {
        char* temp = program;
        if (Run(temp, arg)) {
            printf("%s: no such command\n", buffer);
        }
        program = temp;
    }
    if (program[0] != '!') {
        char* temp = (char*)calloc(strlen(buffer), sizeof(char));
        strcpy(temp, buffer);
        log_push(&Log, temp);
    }
    free(arg);
    free(program);
    return 1;
}


