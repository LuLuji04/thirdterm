#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>

int RunProgram(char * prog, char * argv);

int RunProgram(char * prog, char * argv) {
  pid_t pid = fork();
  int status;
  if(pid == 0) {  /* Child process */
    char * buffer[128];
    memset(buffer, 0, 128);
    buffer[0] = prog;
    char *start = argv, *end = argv;
    int cnt = 0;
    while(*start != '\0') {
      while(*end != ' ' && *end != '\0')
        end++;
      buffer[++cnt] = start;
      start = end;
      while(*start == ' ')
        start++;
      *end = '\0';
      end = start;
    }
    // puts("buffer:");
    // for(int i = 0; i <= cnt; i++){
    //   puts(buffer[i]);
    // }
    // puts("executing:");
    if(execv(prog, buffer) < 0){
      // printf("Error: %s\n", strerror(errno));
      exit(1);
    } else {
      exit(0);
    }
  }

  wait(&status);
  // printf("status:%d\n", status);
  // printf("WIFEXITED:%d\n", WIFEXITED(status));
  // printf("WEXITSTATUS:%d\n",WEXITSTATUS(status));
  if(WIFEXITED(status)){
    if(WEXITSTATUS(status) == 1){
      return -1;
    } else {
      return 0;
    }
  } else {
    puts("Child process exited abnormally");
    return -1;
  }
}

int main(int argc, char* argv[]){
  printf("%d\n", argc);
  for(int i = 0; i < argc; i++){
    puts(argv[i]);
  }
  puts("");
  if(argc < 2)
    printf("Program exit with: %d", RunProgram(argv[1], ""));
  else
    printf("Program exit with: %d", RunProgram(argv[1], argv[2]));
  return 0;
}