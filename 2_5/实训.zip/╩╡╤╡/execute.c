#include"shell.h"
#include"log.h"

int SkipSpaces(int start, char *str);
int RunProgram(char * prog, char * argv);

int execute(char* buffer){
    //def args
    int buf_len = strlen(buffer);
    char *arg = malloc(sizeof(char) * buf_len);
    char *program = malloc(sizeof(char) * buf_len);
    arg[buf_len - 1] = '\0';
    program[buf_len - 1] = '\0';
    arg[0] = '\0';
    program[0] = '\0';

    //del space
    int pos_cmd_start = SkipSpaces(0,buffer);
    int pos = pos_cmd_start;

    //get program
    while(buffer[pos] != ' ' && buffer[pos] != '\0'){
        pos++;
    }
    memcpy(program, buffer + pos_cmd_start, pos - pos_cmd_start);
    program[pos - pos_cmd_start] = '\0';

    //get arg
    pos = SkipSpaces(pos, buffer);
    int space_flg = 0, pos_arg_end = pos, pos_arg_start = pos;
    while(buffer[pos] != '\0'){
        if(buffer[pos] == ' '){
            if(space_flg == 0){
                space_flg = 1;
                pos_arg_end = pos;
            }
        }
        else{
            space_flg = 0;
            pos_arg_end = -1;
        }
        pos++;
    }
    pos_arg_end = pos_arg_end > 0 ? pos_arg_end : pos;
    memcpy(arg, buffer + pos_arg_start,  pos_arg_end - pos_arg_start);
    arg[pos_arg_end - pos_arg_start] = '\0';

    //switch into functions
    if(strcmp("cd", program) == 0){
        cd(arg);
    }
    else if(strcmp("exit", program) == 0){
        return 0;
    }
    else if(strcmp("!#", program) == 0 && arg[0] == '\0'){
        log_history();
    }
    else if(program[0] == '!' && arg[0] == '\0'){
        char *command = log_search(&Log, program + 1);
        printf("%s", command);
    }
    else if(strcmp("ls", program) == 0){
        ls();
    }
    else{
        if(!RunProgram(program, arg)){
            printf("%s: no such command\n", buffer);
        }
    }

    if(program[0] != '!'){
        log_push(&Log, buffer);
    }
    //free pointer
    free(arg);
    free(program);
    return 1;
}


int SkipSpaces(int start, char *str){
    int pos = start;
    while(str[pos] == ' '){
        pos++;
    }
    return pos;
}

int RunProgram(char * prog, char * argv) {
  pid_t pid = fork();
  int status;
  if(pid == 0) {  /* Child process */
    char * buffer[128];
    memset(buffer, 0, 128);
    buffer[0] = prog;
    char *start = argv, *end = argv;
    int cnt = 0;
    while(*start != '\0') {
      while(*end != ' ' && *end != '\0')
        end++;
      buffer[++cnt] = start;
      start = end;
      while(*start == ' ')
        start++;
      *end = '\0';
      end = start;
    }
    // puts("buffer:");
    // for(int i = 0; i <= cnt; i++){
    //   puts(buffer[i]);
    // }
    // puts("executing:");
    if(execv(prog, buffer) < 0){
      // printf("Error: %s\n", strerror(errno));
      exit(1);
    } else {
      exit(0);
    }
  }

  wait(&status);
  // printf("status:%d\n", status);
  // printf("WIFEXITED:%d\n", WIFEXITED(status));
  // printf("WEXITSTATUS:%d\n",WEXITSTATUS(status));
  if(WIFEXITED(status)){
    if(WEXITSTATUS(status) == 1){
      return -1;
    } else {
      return 0;
    }
  } else {
    puts("Child process exited abnormally");
    return -1;
  }
}